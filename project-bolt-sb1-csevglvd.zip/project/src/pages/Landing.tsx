import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Zap, Activity, BarChart3, Leaf, Shield, Cpu, ArrowRight,
  TrendingUp, DollarSign, Gauge, ChevronRight, Menu, X,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const stats = [
  { label: 'Energy Saved', value: 42, suffix: '%', icon: Leaf },
  { label: 'Bill Reduction', value: 38, suffix: '%', icon: DollarSign },
  { label: 'Homes Monitored', value: 12500, suffix: '+', icon: Activity },
  { label: 'CO₂ Reduced', value: 2.4, suffix: 'M kg', icon: TrendingUp },
];

const features = [
  {
    icon: BarChart3,
    title: 'Real-Time Monitoring',
    desc: 'Track every appliance\'s electricity consumption live, with sub-second updates and beautiful visualizations.',
  },
  {
    icon: Cpu,
    title: 'AI-Powered Predictions',
    desc: 'Forecast your monthly bill and energy usage with machine learning models trained on your patterns.',
  },
  {
    icon: Leaf,
    title: 'Carbon Footprint',
    desc: 'Understand your environmental impact and get personalized recommendations to reduce emissions.',
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    desc: 'Bank-grade encryption keeps your energy data private. You own your data, always.',
  },
  {
    icon: Gauge,
    title: 'Smart Analytics',
    desc: 'Daily, weekly, monthly, and yearly comparisons with interactive charts and trend analysis.',
  },
  {
    icon: Zap,
    title: 'IoT Ready',
    desc: 'Connect smart plugs and sensors for automatic appliance-level metering. Future-proof by design.',
  },
];

const navLinks = [
  { label: 'Features', href: '#features' },
  { label: 'How it works', href: '#how' },
  { label: 'Pricing', href: '#pricing' },
];

function AnimatedNumber({ value, suffix }: { value: number; suffix: string }) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !started.current) {
        started.current = true;
        const duration = 1800;
        const start = performance.now();
        const tick = (now: number) => {
          const p = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          setDisplay(value * eased);
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [value]);

  const formatted = value % 1 !== 0 ? display.toFixed(1) : Math.round(display).toLocaleString();
  return <span ref={ref}>{formatted}{suffix}</span>;
}

function MouseGlow() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const move = (e: MouseEvent) => {
      const el = ref.current;
      if (!el) return;
      el.style.transform = `translate(${e.clientX - 250}px, ${e.clientY - 250}px)`;
    };
    window.addEventListener('mousemove', move);
    return () => window.removeEventListener('mousemove', move);
  }, []);
  return (
    <div
      ref={ref}
      className="pointer-events-none fixed top-0 left-0 w-[500px] h-[500px] rounded-full opacity-30 blur-[120px] z-0"
      style={{ background: 'radial-gradient(circle, #2563EB 0%, transparent 70%)' }}
    />
  );
}

function Particles() {
  const particles = Array.from({ length: 18 });
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((_, i) => {
        const left = (i * 53) % 100;
        const size = 2 + (i % 4);
        const delay = (i * 0.7) % 8;
        const duration = 12 + (i % 6);
        return (
          <div
            key={i}
            className="absolute rounded-full bg-[#00C2FF]"
            style={{
              left: `${left}%`,
              width: `${size}px`,
              height: `${size}px`,
              opacity: 0.4,
              animation: `particle-float ${duration}s linear ${delay}s infinite`,
            }}
          />
        );
      })}
    </div>
  );
}

function HeroDashboard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, rotateX: 8 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ rotateY: -3, rotateX: 3 }}
      style={{ transformStyle: 'preserve-3d', perspective: 1200 }}
      className="relative glass-dark rounded-2xl p-5 sm:p-6 w-full max-w-lg mx-auto"
    >
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="text-xs text-slate-400">Live Consumption</p>
          <p className="text-2xl font-bold text-white">2.4 kWh</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-emerald-300 font-medium">Live</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: 'AC', val: '1.2 kW', color: '#00C2FF' },
          { label: 'Fridge', val: '0.3 kW', color: '#2563EB' },
          { label: 'Lights', val: '0.9 kW', color: '#7C3AED' },
        ].map((a) => (
          <div key={a.label} className="glass rounded-xl p-3">
            <p className="text-[10px] text-slate-400 uppercase tracking-wide">{a.label}</p>
            <p className="text-sm font-semibold mt-1" style={{ color: a.color }}>{a.val}</p>
            <div className="mt-2 h-1 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${60 + Math.random() * 30}%`, background: a.color }} />
            </div>
          </div>
        ))}
      </div>

      <svg viewBox="0 0 400 140" className="w-full h-32">
        <defs>
          <linearGradient id="hero-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00C2FF" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#00C2FF" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0,100 L40,80 L80,90 L120,60 L160,70 L200,40 L240,55 L280,30 L320,45 L360,20 L400,35 L400,140 L0,140 Z"
          fill="url(#hero-grad)"
        />
        <path
          d="M0,100 L40,80 L80,90 L120,60 L160,70 L200,40 L240,55 L280,30 L320,45 L360,20 L400,35"
          fill="none"
          stroke="#00C2FF"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ strokeDasharray: 1000, animation: 'draw-line 2s ease-out forwards' }}
        />
        {[[40,80],[120,60],[200,40],[280,30],[360,20]].map(([x,y],i) => (
          <circle key={i} cx={x} cy={y} r="3.5" fill="#0B1220" stroke="#00C2FF" strokeWidth="2" />
        ))}
      </svg>

      <div className="mt-4 flex items-center justify-between text-xs">
        <span className="text-slate-400">Predicted bill</span>
        <span className="text-white font-semibold">$84.20 <span className="text-emerald-400 ml-1">↓ 12%</span></span>
      </div>
    </motion.div>
  );
}

export default function Landing() {
  const navigate = useNavigate();
  const { session } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const goToApp = () => navigate(session ? '/dashboard' : '/signin');

  return (
    <div className="relative min-h-screen bg-[#0B1220] text-white overflow-x-hidden">
      <MouseGlow />
      <Particles />

      {/* Navbar */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'glass-dark py-3' : 'py-5 bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between">
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#00C2FF] flex items-center justify-center shadow-lg shadow-blue-500/30 group-hover:scale-105 transition-transform">
              <Zap className="w-5 h-5 text-white" fill="white" />
            </div>
            <span className="text-xl font-bold tracking-tight">Voltora</span>
          </a>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="text-sm text-slate-300 hover:text-white transition-colors">
                {l.label}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <button onClick={() => navigate('/signin')} className="text-sm text-slate-200 hover:text-white px-4 py-2 transition-colors">
              Sign in
            </button>
            <button
              onClick={() => navigate('/signup')}
              className="btn-primary text-sm font-medium px-5 py-2.5 rounded-lg flex items-center gap-1.5"
            >
              Get started <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <button className="md:hidden p-2" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </nav>

        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="md:hidden glass-dark mx-4 mt-2 rounded-xl p-4 flex flex-col gap-3"
          >
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="text-sm text-slate-200 py-1">
                {l.label}
              </a>
            ))}
            <button onClick={() => navigate('/signin')} className="text-sm text-left py-1.5 text-slate-200">Sign in</button>
            <button onClick={() => navigate('/signup')} className="btn-primary text-sm font-medium px-4 py-2.5 rounded-lg">
              Get started
            </button>
          </motion.div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-36 pb-20 px-5 sm:px-8 z-10">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00C2FF] animate-pulse" />
              <span className="text-xs text-slate-300">AI-ready Energy Intelligence</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-[1.05] tracking-tight">
              Power your home with <span className="text-gradient">intelligence</span>
            </h1>
            <p className="mt-6 text-lg text-slate-300 max-w-xl leading-relaxed">
              Voltora turns your electricity data into clarity. Monitor every appliance,
              predict your bill, and shrink your carbon footprint — all in one beautiful dashboard.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={goToApp}
                className="btn-primary px-7 py-3.5 rounded-xl font-semibold flex items-center gap-2 text-base"
              >
                {session ? 'Open dashboard' : 'Start free'} <ArrowRight className="w-4 h-4" />
              </button>
              <a href="#features" className="btn-outline px-7 py-3.5 rounded-xl font-medium text-base inline-flex items-center gap-2">
                Explore features <ChevronRight className="w-4 h-4" />
              </a>
            </div>
            <div className="mt-8 flex items-center gap-6 text-xs text-slate-400">
              <span className="flex items-center gap-1.5"><Shield className="w-3.5 h-3.5 text-[#00C2FF]" /> Bank-grade security</span>
              <span className="flex items-center gap-1.5"><Leaf className="w-3.5 h-3.5 text-emerald-400" /> Eco-friendly</span>
              <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5 text-[#2563EB]" /> AI predictions</span>
            </div>
          </motion.div>

          <HeroDashboard />
        </div>
      </section>

      {/* Stats */}
      <section className="relative px-5 sm:px-8 py-16 z-10">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-5">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-2xl p-6 hover:border-[#00C2FF]/40 transition-colors"
            >
              <s.icon className="w-6 h-6 text-[#00C2FF] mb-3" />
              <p className="text-3xl font-extrabold">
                <AnimatedNumber value={s.value} suffix={s.suffix} />
              </p>
              <p className="text-sm text-slate-400 mt-1">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative px-5 sm:px-8 py-20 z-10">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-2xl mx-auto mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Everything you need to <span className="text-gradient">save energy</span>
            </h2>
            <p className="mt-4 text-slate-300">
              A complete platform built for homes that want to understand and optimize their electricity use.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -6 }}
                className="glass rounded-2xl p-6 hover:border-[#2563EB]/50 transition-colors group"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#2563EB]/20 to-[#00C2FF]/20 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <f.icon className="w-6 h-6 text-[#00C2FF]" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative px-5 sm:px-8 py-20 z-10">
        <div className="max-w-5xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl font-extrabold text-center mb-14 tracking-tight"
          >
            How it <span className="text-gradient">works</span>
          </motion.h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Add your appliances', desc: 'List your AC, fridge, lights — assign rooms and categories in seconds.' },
              { step: '02', title: 'Voltora learns', desc: 'Our AI analyzes usage patterns and predicts your consumption and bill.' },
              { step: '03', title: 'Save & optimize', desc: 'Get tailored recommendations to cut waste and lower your monthly bill.' },
            ].map((s, i) => (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12 }}
                className="relative"
              >
                <div className="text-5xl font-extrabold text-[#2563EB]/30 mb-3">{s.step}</div>
                <h3 className="text-xl font-semibold mb-2">{s.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="pricing" className="relative px-5 sm:px-8 py-20 z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto glass-dark rounded-3xl p-10 sm:p-14 text-center relative overflow-hidden"
        >
          <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full bg-[#2563EB]/30 blur-[80px]" />
          <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-[#00C2FF]/20 blur-[80px]" />
          <div className="relative">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Ready to take control of your <span className="text-gradient">energy?</span>
            </h2>
            <p className="mt-4 text-slate-300 max-w-xl mx-auto">
              Join thousands of households saving money and the planet with Voltora.
            </p>
            <button
              onClick={goToApp}
              className="btn-primary mt-8 px-8 py-4 rounded-xl font-semibold inline-flex items-center gap-2 text-base"
            >
              {session ? 'Open dashboard' : 'Get started free'} <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative px-5 sm:px-8 py-12 border-t border-white/5 z-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#2563EB] to-[#00C2FF] flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" fill="white" />
            </div>
            <span className="font-bold">Voltora</span>
            <span className="text-xs text-slate-500 ml-2">© {new Date().getFullYear()} Voltora. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-slate-400">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#how" className="hover:text-white transition-colors">How it works</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
