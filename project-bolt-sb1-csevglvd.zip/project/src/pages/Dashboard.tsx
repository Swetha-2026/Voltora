import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Line, Bar, Doughnut,
} from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, BarElement, ArcElement, Tooltip, Legend, Filler,
} from 'chart.js';
import {
  Zap, DollarSign, Leaf, TrendingUp, Bell, LogOut, Menu, X,
  LayoutDashboard, Cpu, BarChart3, FileText, Settings, User,
  Search, Plus,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

ChartJS.register(
  CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Tooltip, Legend, Filler,
);

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', active: true },
  { icon: Cpu, label: 'Appliances' },
  { icon: BarChart3, label: 'Analytics' },
  { icon: FileText, label: 'Reports' },
  { icon: User, label: 'Profile' },
  { icon: Settings, label: 'Settings' },
];

const cards = [
  { label: 'Energy Usage', value: '2.4 kWh', change: '-8%', up: false, icon: Zap, color: '#00C2FF' },
  { label: 'Electricity Bill', value: '$84.20', change: '-12%', up: false, icon: DollarSign, color: '#2563EB' },
  { label: 'Monthly Savings', value: '$31.50', change: '+18%', up: true, icon: TrendingUp, color: '#22c55e' },
  { label: 'Carbon Footprint', value: '142 kg', change: '-5%', up: false, icon: Leaf, color: '#a78bfa' },
];

const appliances = [
  { name: 'Air Conditioner', room: 'Living Room', power: '1.2 kW', hours: '6.5 h/day', icon: 'AC', color: '#00C2FF' },
  { name: 'Refrigerator', room: 'Kitchen', power: '0.3 kW', hours: '24 h/day', icon: 'FR', color: '#2563EB' },
  { name: 'Washing Machine', room: 'Utility', power: '0.5 kW', hours: '1.2 h/day', icon: 'WM', color: '#a78bfa' },
  { name: 'Television', room: 'Living Room', power: '0.15 kW', hours: '4 h/day', icon: 'TV', color: '#22c55e' },
  { name: 'Water Heater', room: 'Bathroom', power: '1.5 kW', hours: '1.5 h/day', icon: 'WH', color: '#f97316' },
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { profile, user, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [range, setRange] = useState<'day' | 'week' | 'month' | 'year'>('week');

  const lineData = useMemo(() => {
    const datasets: Record<string, number[]> = {
      day: [1.8, 2.1, 1.9, 2.4, 2.6, 2.2, 1.7, 1.5, 1.9, 2.3, 2.5, 2.1],
      week: [12, 18, 15, 22, 19, 25, 21],
      month: [64, 72, 68, 80, 76, 88, 82, 90, 78, 85, 92, 88, 80, 76, 84, 90, 86, 78, 82, 88, 92, 86, 80, 78, 84, 90, 88, 82, 86, 84],
      year: [280, 320, 290, 340, 360, 420, 480, 460, 400, 350, 320, 290],
    };
    const labels: Record<string, string[]> = {
      day: ['12a','3a','6a','9a','12p','3p','6p','9p','10p','11p','12a','3a'],
      week: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      month: Array.from({ length: 30 }, (_, i) => `${i + 1}`),
      year: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    };
    return {
      labels: labels[range],
      datasets: [{
        label: 'Consumption (kWh)',
        data: datasets[range],
        borderColor: '#00C2FF',
        backgroundColor: (ctx: { chart: { ctx: CanvasRenderingContext2D; chartArea?: { top: number; bottom: number } } }) => {
          const { ctx: c, chartArea } = ctx.chart;
          if (!chartArea) return 'rgba(0,194,255,0.1)';
          const g = c.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
          g.addColorStop(0, 'rgba(0,194,255,0.4)');
          g.addColorStop(1, 'rgba(0,194,255,0)');
          return g;
        },
        fill: true,
        tension: 0.4,
        borderWidth: 2.5,
        pointRadius: 0,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: '#00C2FF',
      }],
    };
  }, [range]);

  const barData = {
    labels: ['AC', 'Fridge', 'Washer', 'TV', 'Heater', 'Lights'],
    datasets: [{
      label: 'kWh',
      data: [7.8, 7.2, 0.6, 0.6, 2.25, 1.8],
      backgroundColor: ['#00C2FF', '#2563EB', '#a78bfa', '#22c55e', '#f97316', '#eab308'],
      borderRadius: 8,
    }],
  };

  const doughnutData = {
    labels: ['Living Room', 'Kitchen', 'Bedroom', 'Bathroom', 'Utility'],
    datasets: [{
      data: [42, 28, 15, 10, 5],
      backgroundColor: ['#00C2FF', '#2563EB', '#a78bfa', '#22c55e', '#f97316'],
      borderColor: '#0B1220',
      borderWidth: 3,
    }],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(11,18,32,0.95)',
        borderColor: 'rgba(0,194,255,0.3)',
        borderWidth: 1,
        padding: 12,
        titleColor: '#fff',
        bodyColor: '#cbd5e1',
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#64748b', font: { size: 11 } },
      },
      y: {
        grid: { color: 'rgba(255,255,255,0.05)' },
        ticks: { color: '#64748b', font: { size: 11 } },
      },
    },
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const initials = (profile?.full_name || user?.email || 'U')
    .split(' ').map((s) => s[0]).slice(0, 2).join('').toUpperCase();

  return (
    <div className="min-h-screen bg-[#0B1220] text-white flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 glass-dark border-r border-white/5 z-40 transform transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#00C2FF] flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" fill="white" />
            </div>
            <span className="text-lg font-bold">Voltora</span>
          </div>
          <button className="lg:hidden text-slate-400" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="px-4 py-2 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all ${
                item.active
                  ? 'bg-gradient-to-r from-[#2563EB]/20 to-transparent text-white border border-[#2563EB]/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-4.5 h-4.5" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all"
          >
            <LogOut className="w-4.5 h-4.5" />
            Sign out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 min-w-0">
        {/* Topbar */}
        <header className="sticky top-0 z-20 glass-dark border-b border-white/5 px-5 sm:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-slate-300" onClick={() => setSidebarOpen(true)}>
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-lg font-bold">Dashboard</h1>
              <p className="text-xs text-slate-400 hidden sm:block">Welcome back, {profile?.full_name || 'there'}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                placeholder="Search..."
                className="w-48 lg:w-64 pl-9 pr-4 py-2 rounded-lg glass border border-white/10 text-sm text-white placeholder-slate-500 focus:border-[#00C2FF] focus:outline-none"
              />
            </div>
            <button className="relative p-2 rounded-lg glass border border-white/10 hover:border-[#00C2FF]/40 transition-colors">
              <Bell className="w-4.5 h-4.5 text-slate-300" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#00C2FF]" />
            </button>
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#2563EB] to-[#00C2FF] flex items-center justify-center text-sm font-semibold">
              {initials}
            </div>
          </div>
        </header>

        <main className="p-5 sm:p-8 space-y-6">
          {/* Stat cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
            {cards.map((c, i) => (
              <motion.div
                key={c.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="glass rounded-2xl p-5 hover:border-white/20 transition-colors"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${c.color}20`, border: `1px solid ${c.color}40` }}>
                    <c.icon className="w-5 h-5" style={{ color: c.color }} />
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-md ${c.up ? 'bg-emerald-500/15 text-emerald-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
                    {c.change}
                  </span>
                </div>
                <p className="text-2xl font-extrabold">{c.value}</p>
                <p className="text-sm text-slate-400 mt-1">{c.label}</p>
              </motion.div>
            ))}
          </div>

          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Line chart */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="lg:col-span-2 glass rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
                <div>
                  <h3 className="font-semibold">Energy Consumption</h3>
                  <p className="text-xs text-slate-400">Trend over time</p>
                </div>
                <div className="flex gap-1.5 glass rounded-lg p-1">
                  {(['day','week','month','year'] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRange(r)}
                      className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${
                        range === r ? 'bg-[#2563EB] text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <div className="h-64">
                <Line data={lineData} options={chartOptions} />
              </div>
            </motion.div>

            {/* Doughnut */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass rounded-2xl p-5"
            >
              <h3 className="font-semibold mb-1">Usage by Room</h3>
              <p className="text-xs text-slate-400 mb-4">Distribution this month</p>
              <div className="h-48 flex items-center justify-center">
                <Doughnut data={doughnutData} options={{ ...chartOptions, scales: undefined, plugins: { ...chartOptions.plugins, legend: { display: true, position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 }, padding: 12, usePointStyle: true } } } }} />
              </div>
            </motion.div>
          </div>

          {/* Bottom row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Bar chart */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="lg:col-span-2 glass rounded-2xl p-5"
            >
              <h3 className="font-semibold mb-1">Appliance Comparison</h3>
              <p className="text-xs text-slate-400 mb-4">Daily kWh per appliance</p>
              <div className="h-56">
                <Bar data={barData} options={chartOptions} />
              </div>
            </motion.div>

            {/* Prediction card */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="glass-dark rounded-2xl p-5 relative overflow-hidden"
            >
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[#2563EB]/20 blur-[60px]" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="w-4 h-4 text-[#00C2FF]" />
                  <h3 className="font-semibold">Bill Prediction</h3>
                </div>
                <p className="text-xs text-slate-400 mb-5">AI forecast for next month</p>
                <p className="text-4xl font-extrabold">$78.40</p>
                <p className="text-sm text-emerald-400 mt-1">↓ $5.80 vs this month</p>
                <div className="mt-5 space-y-3">
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                      <span>Confidence</span><span>92%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div className="h-full rounded-full bg-gradient-to-r from-[#2563EB] to-[#00C2FF]" style={{ width: '92%' }} />
                    </div>
                  </div>
                  <button className="btn-primary w-full py-2.5 rounded-lg text-sm font-medium mt-2">
                    View full report
                  </button>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Appliances table */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass rounded-2xl p-5"
          >
            <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
              <div>
                <h3 className="font-semibold">Your Appliances</h3>
                <p className="text-xs text-slate-400">{appliances.length} appliances tracked</p>
              </div>
              <button className="btn-primary px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-1.5">
                <Plus className="w-4 h-4" /> Add appliance
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-slate-400 border-b border-white/5">
                    <th className="pb-3 font-medium">Appliance</th>
                    <th className="pb-3 font-medium">Room</th>
                    <th className="pb-3 font-medium">Power</th>
                    <th className="pb-3 font-medium">Daily usage</th>
                    <th className="pb-3 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {appliances.map((a) => (
                    <tr key={a.name} className="border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                      <td className="py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold" style={{ background: `${a.color}20`, color: a.color, border: `1px solid ${a.color}40` }}>
                            {a.icon}
                          </div>
                          <span className="font-medium">{a.name}</span>
                        </div>
                      </td>
                      <td className="py-3.5 text-slate-300">{a.room}</td>
                      <td className="py-3.5 text-slate-300">{a.power}</td>
                      <td className="py-3.5 text-slate-300">{a.hours}</td>
                      <td className="py-3.5 text-right">
                        <button className="text-slate-400 hover:text-[#00C2FF] text-xs font-medium">Edit</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </main>
      </div>
    </div>
  );
}
